/*
Amit Kumar
20CS30003
*/



/*Important Library*/
#include <stdio.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h> 
#include <netinet/in.h>
#include <arpa/inet.h>

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>

/*Function to give error msg to user, and exit*/
void error(const char *msg){
    perror(msg);
    exit(1);
}       



int min(int a,int b){
    if(a<b)return a;
    return b;
}
char* recv_msg(int sockfd){
    char* res=NULL;
    size_t reslen=0,buflen=0;
    char buf[110];
    while(1){
        for(int i=0;i<110;i++)buf[i]='\0';
        int rec_len = recv(sockfd,buf,100,0);
        if(rec_len<=0){
            if(res)free(res);
            close(sockfd);
            perror("recv");
            exit(1);
        }
        buflen=rec_len;
        res=realloc(res,buflen+reslen+1);
        strcpy(res+reslen,buf);
        reslen+=buflen;
        if(buf[rec_len-1]=='\0'){break;}
    } 
    char* inp=NULL;
    inp=malloc(sizeof(char)*(reslen+1));
    strcpy(inp,res);
    if(res)free(res);
    return inp;
}

void send_msg(int newsockfd,char* msg){
    int msg_len=strlen(msg)+1;
    int idx=0;
    while(1){
        int send_len=send(newsockfd,msg+idx,min(100,msg_len-idx),0);
        if(send_len<=0){
            close(newsockfd);
            if(msg)free(msg);
            error("send");
        }
        idx+=send_len;
        if(idx>=msg_len){
            break;
        }
    }
    return ;
}


/*Function which reads an input string of unknown length*/
char* readinputstring(){

    /*We will take input in chunks of size<=200*/
    #define chunk 200


    /*Temporary memeory where we will keep the input string*/
    char* input = NULL;

    /*For replacing '\n' by '\0' in end of string */
    char* iterator;

    /*Final input string to return*/
    char* res;

    /*Temporary buffer to read input in chunks*/
    char tempbuf[chunk];

    /*Length of input/tempbuf string*/
    size_t inputlen=0,templen=0;
    do{
        /*if no input is taken*/
        if(fgets(tempbuf,chunk,stdin)==NULL)break;
        
        /*copy tempbuf into main input 
            string in O(length(tempbuf)) time*/
        templen=strlen(tempbuf);
        input = realloc(input,inputlen+templen+1);
        strcpy(input+inputlen,tempbuf);
        inputlen+=templen;

        /*Do it untill you get '\n' in the end*/
    }while((templen==chunk-1)&&(tempbuf[chunk-2]!='\n'));
    
    iterator=input;
    /*replacing '\n' by '\0' in end of string*/
    while(*iterator != '\n')
        iterator++;
    *iterator='\0';
    
    /*copy final string to res*/
    res=malloc(strlen(input)+1);
    strcpy(res,input);

    /*free memory used by input, which has no use now*/
    free(input);
    return res;

    #undef chunk
}

/*recursive function to calculate the value of expression*/
float cal(char *buf,int *i,int len){
    /*Stores final output*/
    float res=0;

    /*Stores the operator which is going to be used next*/
    char op='+';

    /*Untill whole string is read*/
    while((*i) < len){

        /*Leave space char*/
        if (buf[*i]==' '){
            (*i)++;
            continue;
        }

        /*Read float value and do the operation*/
        if( buf[*i]=='.' || ( buf[*i]>='0' && buf[*i]<='9' ) ){
            /*atof fn converts string arguments to floating*/
            float val=atof(buf + *i);
            
            /*update res*/
            if(op=='+')res+=val;
            else if(op=='-')res-=val;
            else if(op=='*')res*=val;
            else if(op=='/')res/=val;
            while( ((*i) < len) && ( buf[*i]=='.' || ( buf[*i]>='0' && buf[*i]<='9' ) ) ){
                (*i)++;
            }
            continue;
        }

        /*Read new operator and update op*/
        if(buf[*i]=='+'||buf[*i]=='-'||buf[*i]=='*'||buf[*i]=='/'){
            op=buf[*i];
            (*i)++;
            continue;
        }

        /*If we get a '(' call cal function again, with updated index*/
        /*Get value inside '(' and ')' and update res;*/
        if(buf[*i]=='('){
            (*i)++;
            float val=cal(buf,i,len);
            if(op=='+')res+=val;
            else if(op=='-')res-=val;
            else if(op=='*')res*=val;
            else if(op=='/')res/=val;
            continue;
        }

        /*return the res value, since the value inside () bracket is calculated*/
        if(buf[*i]==')'){
            (*i)++;
            return res;
        }
        (*i)++;
    }

    /*return result*/
    return res;
}

/* Function to remove unnecessary spaces from a  string (beginning, end, and multiple spaces in between)*/
char* removeSpaces(char* str){

    char* res = (char*)malloc(strlen(str)+1);
    int i=0,j=0;

    /* remove spaces from beginning*/
    while(str[i]==' '){i++;}

    /* remove spaces from  between*/
    while(str[i]!='\0'){ 
        if(str[i]!=' '){
            res[j]=str[i];
            j++;
        }else{
            res[j]=' ';
            j++;
            while(str[i]==' '){
                i++;
            }
            i--;
        }
        i++;
    }

    /* remove spaces from end*/
    while((j-1>=0) && (res[j-1]==' '))j--; 
    
    /* add '\0' at end*/
    res[j]='\0'; 
    
    /* copy res to res2*/
    char *res2 = (char*)malloc(strlen(res)+1);
    strcpy(res2,res);
    
    /* free res*/
    if(res)free(res);

    return res2;
}

#define SZ 110
int n;
char candid_name[12][25];

void* check(void* arg){
    while(1){
        sleep(300);

    }
}
struct cli
{
    struct sockaddr_in cliaddr;
    int portno;
    int newsockfd;
};
int cnt=0;
char ip_addr[550][550];
int port_no[550];
int main(){
    printf("give n: ");
    scanf("%d",&n);
    fgets(candid_name[0], 24, stdin);
    for(int i=1;i<=n;i++){
        printf("give name %d:",i);
        scanf("%[^\n]%*c", candid_name[i]);
    }
    pthread_t checker;
    pthread_create(&checker,NULL,check,NULL);

    

    int sockfd, newsockfd;/*Socket Descriptors*/
    int clilen;

    struct sockaddr_in serv_addr,cli_addr;
    int i;
    char tempbuf[SZ]; /*message buffer*/
    
    /* The following system call opens a socket.*/
    sockfd = socket(AF_INET,SOCK_STREAM,0);
    if(sockfd<0){
        /*Error Handelling*/
        error("Cannot create socket");
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(20000);

   
    if(bind(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr))<0){
        /*Error Handelling*/
        close(sockfd);
        error("Unable to bind local address");
    }

    if(listen(sockfd,5)<0){
        /*Error Handelling*/
        close(sockfd);
        error("Listen failed");
    }

    char *buf;/*To reiceive data from client*/
    printf("The Server is ready...\n");

    /*iterative server*/
    while(1){
        pthread_t handle;
        
        clilen = sizeof(cli_addr);
        newsockfd = accept(sockfd,(struct sockaddr *)&cli_addr,&clilen);
        if(newsockfd<0){
            /*Error Handelling*/
            free(buf);
            close(sockfd);
            error("Accept failed");
        }
        // pthread_create(&handle,NULL,handle_client,NULL);
        
        // Get the client IP address and port number
        char *client_ip = inet_ntoa(cli_addr.sin_addr);
        int client_port = ntohs(cli_addr.sin_port);
        printf("Connection from %s:%d\n", client_ip, client_port);
        
        for(int i=0;i<cnt;i++){
            if(strcmp(client_ip,ip_addr[i])==0){
                if(client_port==port_no[i]){
                    close(newsockfd);
                    exit(1);
                }
            }
        }
        int n_=n;
        int id_net1 = htonl(n_);
        send(newsockfd, &id_net1, sizeof(id_net1), 0);
        
        for(int i=1;i<=n;i++){
            int id_net = htonl(i);
            // Send the candidate ID to the client
            send(newsockfd, &id_net, sizeof(id_net), 0);
            send_msg(newsockfd,candid_name[i]);
            // sleep(1);
            // printf("ok\n");
        }

        char* buf=recv_msg(newsockfd);

        
        /*convert float value to string*/
        for(int i=0;i<SZ;i++)tempbuf[i]='\0';

        printf("client %s %d voted for : %s",client_ip,client_port,buf);
        /* the following system call closes the socket.*/
        close(newsockfd);
    }

    /*free memory.*/
    free(buf);
    /* the following system call closes the socket.*/
    close(sockfd);

    pthread_join(checker,NULL);
    return 0;
    return 0;
}
