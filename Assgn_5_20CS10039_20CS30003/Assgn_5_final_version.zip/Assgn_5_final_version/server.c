#include "mysocket.h"
#include <stdio.h>

int main(int argc, char *argv[])
{
    int sockfd, newsockfd; /* Socket descriptors */
    socklen_t clilen;
    struct sockaddr_in cli_addr, serv_addr;
    char buf[100]; /* We will use this buffer for communication */
    if (argc != 2)
    {
        printf("Usage: %s <port>\n", argv[0]);
        exit(1);
    }
    int port = atoi(argv[1]);

    if ((sockfd = my_socket(AF_INET, SOCK_MyTCP, 0)) < 0)
    {
        perror("server: can't open stream socket");
        exit(1);
    }
    printf("Socket created\n");

    bzero((char *)&serv_addr, sizeof(serv_addr));

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_addr.sin_port = htons(port);

    if (my_bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
    {
        perror("server: can't bind local address");
        exit(1);
    }
    printf("Socket binded\n");

    my_listen(sockfd, 5);

    while (1)
    {
        clilen = sizeof(cli_addr);
        if ((newsockfd = my_accept(sockfd, (struct sockaddr *)&cli_addr, &clilen)) < 0)
        {
            perror("server: accept error");
            exit(1);
        }
        printf("Socket accepted from %s:%d \r \n", inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port));

        for (int i = 0; i < 20; i++)
        {
            my_recv(newsockfd, buf, 100, 0);
            printf("Message received:%d %s \r \n", i, buf);
        }
        my_close(newsockfd);
    }
    my_close(sockfd);
    

    return 0;
}