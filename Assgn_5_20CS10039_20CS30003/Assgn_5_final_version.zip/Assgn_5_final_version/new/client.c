#include "mysocket.h"
#include <stdio.h>

int main(int argc, char *argv[]){
    int			sockfd ; /* Socket descriptors */
    struct sockaddr_in	serv_addr;
    char buf[100];		/* We will use this buffer for communication */

    if(argc != 2){
        printf("Usage: %s <port>\n", argv[0]);
        exit(1);
    }
    int port = atoi(argv[1]);

    if((sockfd = my_socket(AF_INET, SOCK_MyTCP, 0)) < 0){
        perror("server: can't open stream socket");
        exit(1);
    }



    bzero((char *) &serv_addr, sizeof(serv_addr));

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    serv_addr.sin_port = htons(port);

    if(my_connect(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0){
        perror("server: can't bind local address");
        exit(1);
    }
    printf("Socket connected\n");
    for(int i=0;i<20;i++){
        char *message = "Hello from client";
        my_send(sockfd, message, strlen(message), 0);

    }
    // while(1);
    my_close(sockfd);

    return 0;
}