#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mysocket.h"

/*client process*/
#define PORT 5566
#define IP "127.0.0.1"

int main()
{
    // char *IP = "127.0.0.1";
    int sock;
    struct sockaddr_in addr;
    char buffer[1024];

    if ((sock = my_socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror(" [-]Error in sock\n");
        exit(1);
    }
    printf(" [+]TCP Server my_socket created successfully\n");

    // set the server_addr struct with all zeros
    memset(&addr, '\0', sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(PORT);
    addr.sin_addr.s_addr = inet_addr(IP);

    // my_connect the my_socket to the server_addr
    int status = my_connect(sock, (struct sockaddr *)&addr, sizeof(addr));
    if (status < 0)
    {
        perror(" [-]Error in my_connect\n");
        exit(1);
    }
    printf(" [+]Connection successful to port %d and IP %s \r \n", PORT, IP);

    for(int i=0;i<12;i++){
        // send the message to the server
        char *message = "Hello from client";
        my_send(sock, message, strlen(message), 0);
        printf(" [+]Message sent: %s \r \n", message);
    }
    // my_close(sock);
    while(1);
}