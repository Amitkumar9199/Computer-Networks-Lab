#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "mysocket.h"

/*server process*/
#define PORT 5566
#define IP "127.0.0.1"

int main()
{
    int server_socket, client_socket;            // my_socket descriptors
    struct sockaddr_in server_addr, client_addr; // my_socket address structures
    socklen_t clilen;                            // my_socket length
    char buffer[1024];                           // buffer to read and write data

    if ((server_socket = my_socket(AF_INET, SOCK_STREAM, 0)) < 0) // create a my_socket
    {
        perror(" [-]Error in my_socket\n");
        exit(1);
    }
    printf(" [+]TCP Server my_socket created successfully\n");

    // set the server_addr struct with all zeros
    memset(&server_addr, '\0', sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = inet_addr(IP);
    // my_bind the my_socket to the server_addr
    int status = my_bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)); // my_bind to server
    if (status < 0)
    {
        perror(" [-]Error in my_bind\n");
        exit(1);
    }
    printf(" [+]Binding successful to port %d and IP %s \r \n", PORT, IP);
    listen(server_socket, 5); // listen for connections

    while (1)
    {
        printf("\nListening for incoming connections...\r \n");
        clilen = sizeof(client_addr);
        client_socket = my_accept(server_socket, (struct sockaddr *)&client_addr, &clilen); // my_accept connection from client
        if (client_socket < 0)
        {
            perror(" [-]Error in my_accept\n");
            exit(1);
        }
        printf(" [+]Connection accepted from %s:%d\r \n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
        // clear the buffer
       
    }
}